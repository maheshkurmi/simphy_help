<?xml version='1.0' encoding='ISO-8859-1'?>
<!DOCTYPE helpset PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 2.0//EN"
                         "http://java.sun.com/products/javahelp/helpset_2_0.dtd">

<helpset version="2.0" xml:lang="en">
	<title>SimPHY 5.0- Online Help</title>
	<maps>
		<homeID>introduction</homeID>
		<mapref location="default/map.xml"/>
	</maps>
	<view mergetype="javax.help.AppendMerge">
		<name>TOC</name>
		<label>Content</label>
		<type>javax.help.TOCView</type>
		<data>default/toc.xml</data>
	</view>
	<view mergetype="javax.help.AppendMerge">
		<name>Index</name>
		<label>Index</label>
		<type>javax.help.IndexView</type>
		<data>default/index.xml</data>
	</view>
	<view>
		<name>Search</name>
		<label>Search</label>
		<type>javax.help.SearchView</type>
		<data engine="com.sun.java.help.search.DefaultSearchEngine">default/JavaHelpSearch</data>
	</view>
	<presentation default="true" displayviews="true" displayviewimages="false">
		<name>main</name>
		<size width="850" height="550" />
		<location x="100" y="100" />
		<title>SimPhy 4.0-Help</title>
		<image>simphyhelp_icon</image>
		<toolbar>
			<helpaction image="back">javax.help.BackAction</helpaction>
			<helpaction image="forward">javax.help.ForwardAction</helpaction>
			<helpaction>javax.help.SeparatorAction</helpaction>
			<helpaction image="reload">javax.help.ReloadAction</helpaction>
			<helpaction image="home">javax.help.HomeAction</helpaction>
			<helpaction>javax.help.SeparatorAction</helpaction>
			<helpaction image="print">javax.help.PrintAction</helpaction>
			<helpaction image="preferences">javax.help.PrintSetupAction</helpaction>
		</toolbar>
	</presentation>
	<impl>
		<helpsetregistry helpbrokerclass="com.software7.apps.helen.help.S7HelpBroker" />
	</impl>
</helpset>
